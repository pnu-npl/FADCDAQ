#ifdef __CINT__

//#pragma link off all globals;
//#pragma link off all classes;
//#pragma link off all functions;

//#pragma link C++ class nk_context!;
//#pragma link C++ class nk_device!;
//#pragma link C++ class nk_device_handle!;
#pragma link C++ class NKNKFADC500!;

#endif
