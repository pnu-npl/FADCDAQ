#include "TFile.h"
#include "TTree.h"
#include "TString.h"

#include <stdio.h>
#include <bitset>
#include <cstdlib>
#include <iostream>

using namespace std;

void jbnu_daq_decode(const char* inFile = "10015.dat")
{
	cout <<Form("Start decoding for %s...\n", inFile);

	//Get data file size (the size should be < 2 GB)
	FILE *fp = fopen(inFile, "rb");
	fseek(fp, 0L, SEEK_END);
	int file_size = ftell(fp);
	fclose(fp);

	//Variables
	char header[32];
	char data[2048];
	int data_read = 0;

	//Output
	TString inFileName = inFile;
	inFileName.ReplaceAll("dat", "root");
	TFile* F = new TFile(Form("out_%s", inFileName.Data()), "recreate");
	TTree* T = new TTree("T", "Spectrum");
	TTree* U = new TTree("U", "Waveform");
	int t_data_length;
	int t_run_number;
	int t_mid;
	int t_channel;
	int t_trigger_type;
	int t_tcb_trigger_number;
	ULong64_t t_tcb_trigger_time;
	int t_local_trigger_number;
	int t_local_trigger_pattern;
	ULong64_t t_local_gate_time;
	int t_charge[32];
	int t_timing[32];
	int t_hitFlag[32];
	int t_wave_length;
	int t_adc[1000];
	T->Branch("data_length",           &t_data_length,           "data_length/I");
	T->Branch("run_number",            &t_run_number,            "run_number/I");
	T->Branch("mid",                   &t_mid,                   "mid/I");
	T->Branch("channel",               &t_channel,               "channel/I");
	T->Branch("trigger_type",          &t_trigger_type,          "trigger_type/I");
	T->Branch("tcb_trigger_number",    &t_tcb_trigger_number,    "tcb_trigger_number/I");
	T->Branch("tcb_trigger_time",      &t_tcb_trigger_time,      "tcb_trigger_time/l");
	T->Branch("local_trigger_number",  &t_local_trigger_number,  "local_trigger_number/I");
	T->Branch("local_trigger_pattern", &t_local_trigger_pattern, "local_trigger_pattern/I");
	T->Branch("local_gate_time",       &t_local_gate_time,       "local_gate_time/l");
	T->Branch("charge",                t_charge,                 "charge[32]/I");
	T->Branch("timing",                t_timing,                 "timing[32]/I");
	T->Branch("hit_flag",              t_hitFlag,                "hit_flag[32]/I");
	U->Branch("wave_length",           &t_wave_length,           "wave_length/I");
	U->Branch("adc",                   t_adc,                    "adc[wave_length]/I");

	//Open data file and read event by event
	fp = fopen(inFile, "rb");

	while (data_read < file_size)
	{
		//Reset tree dummy variables
		t_data_length = -999;
		t_run_number = -999;
		t_mid = -999;
		t_channel = -999;
		t_trigger_type = -999;
		t_tcb_trigger_number = -999;
		t_tcb_trigger_time = 0;
		t_local_trigger_number;
		t_local_trigger_pattern;
		t_local_gate_time = 0;
		for (int a=0; a<32; a++) t_charge[a] = -999;
		for (int a=0; a<32; a++) t_timing[a] = -999;
		for (int a=0; a<32; a++) t_hitFlag[a] = -999;
		t_wave_length = -999;
		for (int a=0; a<1000; a++) t_adc[a] = -999;

		//Read header
		//++++++++++++++++++++++++++++++++++++++++++++

		fread(header, 1, 32, fp);

		int data_length = 0;
		for (int a=0; a<4; a++) data_length += ((int)(header[a] & 0xFF) << 8*a);

		int run_number = 0;
		for (int a=0; a<2; a++) run_number += ((int)(header[a+4] & 0xFF) << 8*a);

		int trigger_type = ((int)header[6] & 0xFF);

		int tcb_trigger_number = 0;
		for (int a=0; a<4; a++) tcb_trigger_number += ((int)(header[a+7] & 0xFF) << 8*a);

		long long tcb_trigger_fine_time = ((long long)header[11] & 0xFF);

		long long tcb_trigger_coarse_time = 0;
		for (int a=0; a<3; a++) tcb_trigger_coarse_time += ((long long)(header[a+12] & 0xFF) << 8*a);

		long long tcb_trigger_time = (tcb_trigger_fine_time * 8) + (tcb_trigger_coarse_time * 1000);

		int mid = ((int)header[15] & 0xFF);

		int channel = ((int)header[16] & 0xFF);

		int local_trigger_number = 0;
		for (int a=0; a<4; a++) local_trigger_number += ((int)(header[a+17] & 0xFF) << 8*a);

		int local_trigger_pattern = 0;
		for (int a=0; a<4; a++) local_trigger_pattern += ((int)(header[a+21] & 0xFF) << 8*a);

		long long local_gate_fine_time = ((long long)header[25] & 0xFF);

		long long local_gate_coarse_time = 0;
		for (int a=0; a<6; a++) local_gate_coarse_time += ((long long)(header[a+26] & 0xFF) << 8*a);

		long long local_gate_time = (local_gate_fine_time * 8) + (local_gate_coarse_time * 1000);

		t_data_length           = data_length;
		t_run_number            = run_number;
		t_mid                   = mid;
		t_channel               = channel;
		t_trigger_type          = trigger_type;
		t_tcb_trigger_number    = tcb_trigger_number;
		t_tcb_trigger_time      = tcb_trigger_time;
		t_local_trigger_number  = local_trigger_number;
		t_local_trigger_pattern = local_trigger_pattern;
		t_local_gate_time       = local_gate_time;
		
		//Read body, data_length - 32 bytes (header)
		//++++++++++++++++++++++++++++++++++++++++++++

        fread(data, 1, data_length - 32, fp);

		int charge[32] = {0};
		int timing[32] = {0};
		int hitFlag[32] = {0};

		int wave_length = (data_length - 32) / 2;
		int adc = 0;

		if (channel == 0) //Spectrum data
		{
			for (int ch=0; ch<32; ch++)
			{
				for (int a=0; a<3; a++) charge[ch] += ((int)(data[6 * ch + a + 0] & 0xFF) << 8*a);
				for (int a=0; a<2; a++) timing[ch] += ((int)(data[6 * ch + a + 3] & 0xFF) << 8*a);
				hitFlag[ch] = data[6 * ch + 5] & 0xFF;
				//cout <<ch <<" " <<charge[ch] <<endl;

				t_charge[ch]  = charge[ch];
				t_timing[ch]  = timing[ch];
				t_hitFlag[ch] = hitFlag[ch];
			}//a

			T->Fill();
		}
		else //Waveform data
		{
			t_wave_length = wave_length;

			for (int a=0; a<wave_length; a++)
			{
				int t_adc1 = (data[2 * a + 0] & 0xFF);
				int t_adc2 = (data[2 * a + 1] & 0xFF) << 8;
				adc = t_adc1 + t_adc2;

				#if 1
				if (adc > 65000) //Flip 0 and 1 of the adc bits
				{
					//What in the name of this stupid sxxx... flip all 0 and 1

					//string b1 = std::bitset< 8>(t_adc1).to_string();
					//string b2 = std::bitset<16>(t_adc2).to_string();
					int u_adc1 = (~(data[2 * a + 0] & 0xFF));
					int u_adc2 = (~(data[2 * a + 1] & 0xFF)) << 8;
					string c1 = std::bitset< 8>(u_adc1).to_string();
					string c2 = std::bitset<16>(u_adc2).to_string();
					unsigned long d1 = std::bitset< 8>(c1).to_ulong();
					unsigned long d2 = std::bitset<16>(c2).to_ulong();

					adc = d1 + d2;
				}
				#endif

				//cout <<t_wave_length <<" " <<channel <<" " <<a <<" " <<adc <<endl;
				t_adc[a] = adc;
			}

			U->Fill();
		}

		data_read = data_read + data_length;
	}//while

	fclose(fp);

	F->Write();
	F->Close();

	return;
}//Main
