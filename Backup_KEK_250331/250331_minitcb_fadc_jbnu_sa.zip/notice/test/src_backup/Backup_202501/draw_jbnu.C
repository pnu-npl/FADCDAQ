#include "TFile.h"
#include "TLine.h"
#include "TString.h"
#include "TTree.h"

#include <iostream>
#include <fstream>

#include "/home/npl/jbnu_daq/notice/test/DrawInfo.h"

using namespace std;

void draw_jbnu(const char* inFile = "out_10017.root", const char* logFile = "setlog.txt", bool PRINT = false)
{
	// Open file
	//-------------------------------------------

	TFile* F = TFile::Open(inFile);
	TTree* T = (TTree*)F->Get("T"); //Spectrum
	TTree* U = (TTree*)F->Get("U"); //Wavefrom

	//ckim
	const int nCh = 32;
	const int nSmpMax = 1000;

    int t_run_number;
    int t_mid;
    int t_channel;
    int t_trigger_type;
    int t_tcb_trigger_number;
    ULong64_t t_tcb_trigger_time;
    int t_local_trigger_number;
    int t_local_trigger_pattern;
    ULong64_t t_local_gate_time;
    int t_charge[nCh];
    int t_timing[nCh];
    int t_hitFlag[nCh];
    int t_wave_length;
    int t_adc[nSmpMax];
    T->SetBranchAddress("run_number",            &t_run_number);
    T->SetBranchAddress("mid",                   &t_mid);
    T->SetBranchAddress("channel",               &t_channel);
    T->SetBranchAddress("trigger_type",          &t_trigger_type);
    T->SetBranchAddress("tcb_trigger_number",    &t_tcb_trigger_number);
    T->SetBranchAddress("tcb_trigger_time",      &t_tcb_trigger_time);
    T->SetBranchAddress("local_trigger_number",  &t_local_trigger_number);
    T->SetBranchAddress("local_trigger_pattern", &t_local_trigger_pattern);
    T->SetBranchAddress("local_gate_time",       &t_local_gate_time);
    T->SetBranchAddress("charge",                t_charge);
    T->SetBranchAddress("timing",                t_timing);
    T->SetBranchAddress("hit_flag",              t_hitFlag);
    U->SetBranchAddress("wave_length",           &t_wave_length);
    U->SetBranchAddress("adc",                   t_adc);

	const int nEvtSpec = T->GetEntriesFast();
	const int nEvtWave = U->GetEntriesFast();

	// Containers
	//-------------------------------------------

	TH1F* H1_mult = new TH1F("H1_mult", "", nEvtSpec,0,nEvtSpec); H1_mult->Sumw2();
	TH2F* H2_charge = new TH2F("H2_charge", "", nEvtSpec,0,nEvtSpec, nCh,0.5,nCh+0.5); H2_charge->Sumw2();
	TH2F* H2_hit = new TH2F("H2_hit", "", nCh/2,0.5,nCh/2+0.5, nCh/2,nCh/2+0.5,nCh+0.5); H2_hit->Sumw2();
	//TH2F* H2_timing[nCh];
	//for (int a=0; a<nCh; a++) H2_timing[a] = new TH2F(Form("H2_timing_%i", a+1), "");
	vector<int> hitX;
	vector<int> hitY;

	TH2F* H2_wave[nCh];
	int waveLen = 0; U->GetEntry(0); waveLen = t_wave_length;
	for (int a=0; a<nCh; a++)
	{
		H2_wave[a] = new TH2F(Form("H2_wave_%i", a+1), "", nEvtSpec,0,nEvtSpec, waveLen,0,waveLen);
		H2_wave[a]->Sumw2();
	}

	// Loop over tree
	//-------------------------------------------

	for (int a=0; a<nEvtSpec; a++)
	{
		T->GetEntry(a);

		//cout <<a <<endl;
		hitX.clear();
		hitY.clear();
		for (int b=0; b<nCh; b++) 
		{
			//cout <<Form("%2i %5i %4i %4i\n", b, t_charge[b], t_timing[b], t_hitFlag[b]);
			if (t_hitFlag[b] == true)
			{
				H1_mult->Fill(a);
				H2_charge->SetBinContent(a+1, b+1, t_charge[b]);

				if      (b+1 <= 16) hitX.push_back(b+1);
				else if (b+1 <= 32) hitY.push_back(b+1);
			}
		}

		for (unsigned int x=0; x<hitX.size(); x++)
		for (unsigned int y=0; y<hitY.size(); y++)
		{
			H2_hit->Fill(hitX[x], hitY[y]);
			//cout <<hitX[x] <<" " <<hitY[y] <<endl;
		}
	}//a, spec

	int temp_ch = 0;
	int temp_evtSpec = 0;
	for (int a=0; a<nEvtWave; a++)
	{
		U->GetEntry(a);

		if (a > nCh * nEvtSpec) break;	
		if (t_wave_length != waveLen) cout <<Form("WARNING! irregular wavelength in event %i\n", a);

		//Check hit_flag
		const int hit = H2_charge->GetBinContent(temp_evtSpec+1, temp_ch+1);
		const bool hitFlag = hit>0?true:false;

		//Get waveform
		const int nWave = t_wave_length;
		for (int b=0; b<nWave; b++)
		{
			//cout <<a <<" " <<temp_evtSpec <<" " <<temp_ch <<" " <<b <<" " <<t_adc[b] <<endl;
			if (hitFlag) H2_wave[temp_ch]->SetBinContent(temp_evtSpec+1, b+1, t_adc[b]);
		}//b, sampling index
		temp_ch++;

		if (temp_ch == nCh)
		{
			temp_ch = 0;
			temp_evtSpec++;
		}
	}//a, wave

	// Draw
	//-------------------------------------------

	TString runNo = inFile;
	runNo.ReplaceAll("out_", "");
	runNo.ReplaceAll(".root", "");

	TCanvas* c1 = new TCanvas(Form("run%s_c1", runNo.Data()), "Fast_data", 800*2, 600*2); c1->Divide(3, 2);
	c1->cd(1)->SetLogz();
	H2_charge->GetZaxis()->SetLabelSize(0.03);
	H2_charge->SetTitle("Charge;Event;Ch");
	H2_charge->SetStats(false);
	H2_charge->DrawCopy("colz");
	TLine* L1 = new TLine(0, 16.5, nEvtSpec, 16.5);
	L1->SetLineColor(2);
	L1->SetLineStyle(2);
	L1->SetLineWidth(2);
	L1->Draw();
	c1->cd(2)->SetLogy(); gPad->SetGrid(1, 0);
	TH1F* H1_charge = (TH1F*)H2_charge->ProjectionY();
	H1_charge->Scale(1./nEvtSpec);
	H1_charge->SetStats(false);
	H1_charge->SetTitle("Charge (norm. by # of events);Ch");
	H1_charge->DrawCopy("hist e");
	TLine* L2 = new TLine(16.5, H1_charge->GetMinimum(), 16.5, H1_charge->GetMaximum());
	L2->SetLineColor(2);
	L2->SetLineStyle(2);
	L2->SetLineWidth(2);
	L2->Draw();
	c1->cd(4);
	H1_mult->SetMaximum(H1_mult->GetMaximum()+10);
	H1_mult->SetTitle("# of fired channels;Event");
	H1_mult->DrawCopy("hist");
	gStyle->SetOptFit();
	TF1* F1_mult = new TF1("F1_mult", "pol0", 0, nEvtSpec);
	F1_mult->SetLineColor(2);
	F1_mult->SetLineWidth(2);
	F1_mult->SetLineStyle(2);
	H1_mult->Fit(F1_mult->GetName(), "EQR", "kRed", 0, nEvtSpec);
	c1->cd(5);
	H2_hit->SetStats(false);
	H2_hit->SetTitle("Hit (all events);FEE1;FEE2");
	H2_hit->DrawCopy("colz");

	// Write out information about setups
	c1->cd(3);
	TLegend* l1 = (TLegend*)generalInfo(logFile);
	l1 -> AddEntry("", runNo, "h");
	l1 -> Draw();

	c1->cd(6);
	TLegend* l2 = (TLegend*)channelThresh(logFile);
	l2 -> Draw();

	TCanvas* c2[2];
	TH1F* H1_temp = new TH1F();
	for (int a=0; a<2; a++)
	{
		c2[a] = new TCanvas(Form("run%s_c2_%i", runNo.Data(), a), Form("Waveform_%i", a), 800*2, 600*2);
		c2[a]->Divide(4, 4);
	}
	for (int a=0; a<nCh; a++)
	{
		const int id_cvs = (a<nCh/2)?0:1;
		const int id_pad = (a<nCh/2)?(a+1):(a-nCh/2+1);
		c2[id_cvs]->cd(id_pad);//->SetLogz();
		//H2_wave[a]->SetStats(false);
		//H2_wave[a]->SetTitle(Form("Ch %i", a+1));
		//H2_wave[a]->Draw("colz");
		float xMax = 0;
		float yMax = 0;
		const int nEvt = H2_wave[a]->GetNbinsX();
		for (int b=0; b<nEvt; b++)
		{
			if (H2_wave[a]->Integral(b+1, b+1, 1, 496) == 0) continue;

			H1_temp->Reset();
			H1_temp = (TH1F*)H2_wave[a]->ProjectionY("", b+1, b+1);
			float xMaxTemp = H1_temp->GetBinCenter(H1_temp->GetMaximumBin());
			float yMaxTemp = H1_temp->GetBinContent(H1_temp->GetMaximumBin());
			if (yMaxTemp != 0 && yMaxTemp > yMax)
			{
				xMax = xMaxTemp;
				yMax = yMaxTemp;
			}
		}//b

		TH1F* H1_frame = new TH1F(Form("H1_frame_%i", a), "", 1, xMax-25, xMax+35);
		H1_frame->SetStats(false);
		H1_frame->SetTitle(Form("Ch %i, Sampling index vs. ADC", a+1));
		H1_frame->GetXaxis()->SetLabelSize(0.05);
		H1_frame->GetYaxis()->SetLabelSize(0.05);
		H1_frame->GetYaxis()->SetRangeUser(0, yMax*1.2);
		H1_frame->DrawCopy("");
		for (int b=0; b<nEvt; b++)
		{
			if (H2_wave[a]->Integral(b+1, b+1, 1, 496) == 0) continue;
			H1_temp = (TH1F*)H2_wave[a]->ProjectionY("", b+1, b+1);
			H1_temp->SetLineColor(1);
			H1_temp->DrawCopy("hist e same");
		}//b
		TLine *L1 = new TLine(xMax-25, 250, xMax+35, 250);
		L1->SetLineColor(2);
		L1->SetLineWidth(2);
		L1->SetLineStyle(2);
		L1->Draw();
	}//a

	if (PRINT) c1->Print(Form("%s.png", c1->GetName()));
	if (PRINT) for (int a=0; a<2; a++) c2[a]->Print(Form("%s.png", c2[a]->GetName()));

	//F->Close();
	return;
}//Main
