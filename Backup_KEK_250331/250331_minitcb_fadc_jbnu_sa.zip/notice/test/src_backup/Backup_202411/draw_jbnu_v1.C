#include "TFile.h"
#include "TTree.h"
#include "TString.h"

#include <iostream>
#include <fstream>
#include <filesystem>
using namespace std;

void draw_jbnu(const char* inFile = "out_10015.root")
{
	// Open file
	//-------------------------------------------

	TFile* F = TFile::Open(inFile);
	TTree* T = (TTree*)F->Get("T"); //Spectrum
	TTree* U = (TTree*)F->Get("U"); //Wavefrom

	//ckim
	const int nCh = 32;
	const int nSmpMax = 1000;

    int t_run_number;
    int t_mid;
    int t_channel;
    int t_trigger_type;
    int t_tcb_trigger_number;
    ULong64_t t_tcb_trigger_time;
    int t_local_trigger_number;
    int t_local_trigger_pattern;
    ULong64_t t_local_gate_time;
    int t_charge[nCh];
    int t_timing[nCh];
    int t_hitFlag[nCh];
    int t_wave_length;
    int t_adc[nSmpMax];
    T->SetBranchAddress("run_number",            &t_run_number);
    T->SetBranchAddress("mid",                   &t_mid);
    T->SetBranchAddress("channel",               &t_channel);
    T->SetBranchAddress("trigger_type",          &t_trigger_type);
    T->SetBranchAddress("tcb_trigger_number",    &t_tcb_trigger_number);
    T->SetBranchAddress("tcb_trigger_time",      &t_tcb_trigger_time);
    T->SetBranchAddress("local_trigger_number",  &t_local_trigger_number);
    T->SetBranchAddress("local_trigger_pattern", &t_local_trigger_pattern);
    T->SetBranchAddress("local_gate_time",       &t_local_gate_time);
    T->SetBranchAddress("charge",                t_charge);
    T->SetBranchAddress("timing",                t_timing);
    T->SetBranchAddress("hit_flag",              t_hitFlag);
    U->SetBranchAddress("wave_length",           &t_wave_length);
    U->SetBranchAddress("adc",                   t_adc);

	const int nEventsSpec = T->GetEntriesFast();
	const int nEventsWave = U->GetEntriesFast();

	// Containers
	//-------------------------------------------

	TH2F* H2_x = new TH2F("H2_x", "FEE 1;Event;Ch", nEventsSpec, 0, nEventsSpec, nCh, 0, nCh);
	TH2F* H2_y = new TH2F("H2_y", "FEE 2;Event;Ch", nEventsSpec, 0, nEventsSpec, nCh, 0, nCh);
	H2_x->GetZaxis()->SetLabelSize(0.02); H2_x->Sumw2();
	H2_y->GetZaxis()->SetLabelSize(0.02); H2_y->Sumw2();

	// Loop over tree
	for (int a=0; a<nEventsSpec; a++)
	{
		T->GetEntry(a);

		//cout <<a <<endl;
		for (int b=0; b<nCh; b++) 
		{
			//cout <<Form("%2i %5i %4i %4i\n", b, t_charge[b], t_timing[b], t_hitFlag[b]);
			if (t_hitFlag[b] == true)
			{
				if (b < nCh/2) H2_x->SetBinContent(a, b, t_charge[b]);
				else           H2_y->SetBinContent(a, b, t_charge[b]);
			}
		}
		//cout <<endl;

	}//a

	TCanvas* c1 =  new TCanvas("c1", "", 800*2, 600*2); c1->Divide(2, 2);
	c1->cd(1); H2_x->SetStats(false); H2_x->GetYaxis()->SetRangeUser(0, nCh/2); H2_x->DrawCopy("colz");
	c1->cd(2); H2_y->SetStats(false); H2_y->GetYaxis()->SetRangeUser(nCh/2, nCh); H2_y->DrawCopy("colz");
	c1->cd(3); H2_x->ProjectionY()->DrawCopy("hist e");
	c1->cd(4); H2_y->ProjectionY()->DrawCopy("hist e");

	// Store canvas to pdf
	TString pdfStoreDir = "data_20241107/pdfs";
	
	// Extracting stem of inputfile
	filesystem::path fileStem(inFile);
	//TString pdfFile = Form("EventByChannel_%s.pdf", fileStem.stem().c_str());
	//TString pdfFileName = pdfStoreDir + "/" + pdfFile;
	TString pdfFileName = Form("EventByChannel_%s.pdf", fileStem.stem().c_str());

	c1 -> SaveAs(pdfFileName);

	//F->Close();
	return;
}//Main
