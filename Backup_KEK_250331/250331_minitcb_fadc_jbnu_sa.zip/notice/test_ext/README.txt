<Deleting previous setting>
make clean -f Makefile_set

<Making current setting>
make -f Makefile_set

Same commands are used to make run~.exe

<Taking data>

0. Turn on the JBNU DAQ machine
1. ./set_JBNU_DAQ.exe -> setlog.txt is generated for 
2. ./run_JBNU_DAQ.exe (sid#) (run#) (runtime) -> Takes in data
2. perl decode_and_draw.pl -> Decodes and draw plots. Automatically stores the results into 'data_<date>' directory.

